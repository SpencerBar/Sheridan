exports.user = "barnessp";
exports.pass = "5XJWhjAYS&f";
exports.database = "barnessp_node";