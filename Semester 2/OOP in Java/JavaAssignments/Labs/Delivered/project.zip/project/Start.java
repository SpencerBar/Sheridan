package project;

public class Start {
    public static void main(String args[])
    {
                  
    Number a1 = new Number(5);

    Number b1 = new Number(6);
    
    System.out.println("this is a: " + a1.a + " this is b: " + b1.a);
    Swap.swap(a1,b1);
    System.out.println("this is a: " + a1.a + " this is b: " + b1.a);
            
    }
}


