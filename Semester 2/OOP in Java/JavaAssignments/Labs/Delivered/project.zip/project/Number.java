package project;

public class Number {
    int a;

    public Number(int a) {
        this.a = a;
    }
    
}
