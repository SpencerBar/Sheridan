package project;

public class Swap {
    public static void swap(Number a1,Number b1){
        int tempA = a1.a;
        a1.a = b1.a;
        b1.a = tempA;
        System.out.println("this is a: " + a1.a + " this is b: " + b1.a);
    }        
}
