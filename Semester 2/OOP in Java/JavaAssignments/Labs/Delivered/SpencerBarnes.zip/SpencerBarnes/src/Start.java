public class Start {
    public static void main(String[] args) throws Exception {
        
        ReportCard student1 = new ReportCard();
        student1.studentName = "Spencer";
        student1.studentId = 1;
        student1.currentGrade = 100;
        ReportCard student2 = new ReportCard();
        student2.studentName = "Barnes";
        student2.studentId = 2;
        student2.currentGrade = 90;
        ReportCard student3 = new ReportCard();
        student3.studentName = "Robert";
        student3.studentId = 3;
        student3.currentGrade = 80;


        System.out.println(student1.getReport());
        System.out.println(student2.getReport());
        System.out.println(student3.getReport());

    }
}
