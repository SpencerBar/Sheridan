public class ReportCard{
    String studentName;
    int studentId;
    int currentGrade;
     
    public String getReport(){
      return this.studentName + " "+ this.studentId + " " + this.currentGrade;
    }
    

}